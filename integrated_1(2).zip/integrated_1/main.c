

/**
 * main.c
 */

#include "open_interface.h"
#include "uart-interrupt.h"
#include "boundary_detection.h"
#include "lcd.h"
#include "Timer.h"
#include "movement.h"
#include "manual_movement.h"
#include "scan.h"
#include "servo.h"
#include "world_map.h"

int main(void)
{
       timer_init(); // Must be called before lcd_init(), which uses timer functions
       lcd_init();
       scan_init();

       scan_feature_enable(1);

       oi_t *sensor_data = oi_alloc(); // do this only once at start of main()
       oi_init(sensor_data); // do this only once at start of main()

       //servo_calibrate();


       //right_calibration = 8500; //Cybot 23
       //left_calibration = 35700; //cybot 23

       //right_calibration = 7400; //Cybot 24
       //left_calibration = 35100; //cybot 24

       //right_calibration = 8600; //Cybot 08
       //left_calibration = 35800; //cybot 08

       //right_calibration = 8900; //Cybot 21
       //left_calibration = 37700; //cybot 21

       //right_calibration = 7200; //Cybot 20
       //left_calibration = 35000; //cybot 20

       right_calibration = 6500; //Cybot 1
       left_calibration = 34400; //cybot 1

       world_map_init();

       while(1){

           oi_update(sensor_data);
           pose_update(sensor_data);

           uint32_t last_pose_send_ms = 0;
           uint32_t now = timer_getMillis();
           if(now - last_pose_send_ms > 100){
               world_map_send_position();
               last_pose_send_ms = now;
           }


           /*
           update_cliff_sensors(sensor_data);
           boundary_status_t s = avoid_hole_boundary(sensor_data);
           if (s != BOUNDARY_CLEAR){
               continue;
           }
           */

           manual_driving(sensor_data);

       }



}
